# JavaLinkShortener
This is my week-2 internship project in motioncut.
